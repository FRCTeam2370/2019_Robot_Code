//Drive
package org.usfirst.frc.team2370.robot;


import edu.wpi.first.wpilibj.CANTalon;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.RobotDrive.MotorType;
import edu.wpi.first.wpilibj.SampleRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj.CANSpeedController;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Relay;




/**
 * This is a demo program showing how to use Mecanum control with the RobotDrive class.
 */
public class Robot extends SampleRobot {
	
    RobotDrive robotDrive;
    Joystick leftstick;
    Joystick rightstick;

    DigitalInput testswitch;

  
    Relay testrelay;
    CANTalon elbow;
    CANTalon shooter;
    
    
    
    // Channels for the wheels
    CANTalon LeftMotor1 = new CANTalon(13);
    CANTalon LeftMotor2 = new CANTalon(14);
    CANTalon RightMotor1 = new CANTalon(15);
    CANTalon RightMotor2 = new CANTalon(16);
        
    CANTalon Winch1 = new CANTalon(8);
    CANTalon Winch2 = new CANTalon(9);
    
    
    
    
    // The channel on the driver station that the joystick is connected to
    final int joystickChannel	= 0;
    
    

    public Robot() {
    	
        robotDrive = new RobotDrive(LeftMotor1,LeftMotor2,RightMotor1,RightMotor2);
    	
        robotDrive.setExpiration(0.1);

        leftstick = new Joystick(1);
        rightstick = new Joystick(2);
                
        testswitch = new DigitalInput(0);
        testrelay = new Relay(1);
    }
        

    /**
     * Runs the motors with Mecanum drive.
     */
    public void operatorControl() {
        robotDrive.setSafetyEnabled(true);
        while (isOperatorControl() && isEnabled()) {
        	
        	// Use the joystick X axis for lateral movement, Y axis for forward movement, and Z axis for rotation.
        	// This sample does not use field-oriented drive, so the gyro input is set to zero.
            // robotDrive.tankDrive(frontRightChannel, frontLeftChannel); 
        	
            LeftMotor1.set( -1 * leftstick.getY() );
            LeftMotor2.set( -1 * leftstick.getY() );
            RightMotor1.set(  rightstick.getY() );
            RightMotor2.set(  rightstick.getY() );
            
            
            Timer.delay(0.005);	// wait 5ms to avoid hogging CPU cycles - 200Hz

            /*
			if(leftstick).getAxis(Y) == true)
			{
				leftstick.setDirection(kForward);
				
				rightstick.setDirection(kForward)
			}
			*/
 
			if(testswitch.get()  == true)
            {
            	SmartDashboard.putBoolean("Test Switch", testswitch.get() );
            }
            else
            {
            	SmartDashboard.putBoolean("Test Switch", testswitch.get() );
            }

            if(leftstick.getRawButton(1)==true)
            {
            	testrelay.set(Relay.Value.kOn);
            	testrelay.setDirection(Relay.Direction.kForward);
            }
            	
            if(leftstick.getRawButton(2)==true)
            {
            	testrelay.set(Relay.Value.kOn);
            	testrelay.setDirection(Relay.Direction.kReverse);
            }
            if(leftstick.getRawButton(3)==true)
            {
            	testrelay.set(Relay.Value.kOff);
            }
           if (rightstick.getRawButton(2)==true);
           {
        	   Winch1.set(1.0);
        	   Winch2.set(1.0);
           }
           if (rightstick.getRawButton(3)==true)
           {
        	   Winch1.set(-1.0);
        	   Winch2.set(-1.0);
           }
           else
           {
        	   Winch1.set(0);
        	   Winch2.set(0);
           }
           if(leftstick.getRawButton(4))
		   {
			   shooter.set(1.0);
			   elbow.set(1.0);
        }
    }
}
		                            
				
				
			}
