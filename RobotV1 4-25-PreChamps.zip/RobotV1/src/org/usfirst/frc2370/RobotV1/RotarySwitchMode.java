package org.usfirst.frc2370.RobotV1;

public enum RotarySwitchMode
{
	A,
	B,
	C,
	D
}
