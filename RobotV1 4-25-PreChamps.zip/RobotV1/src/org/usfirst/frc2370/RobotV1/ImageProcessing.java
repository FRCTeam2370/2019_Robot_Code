package org.usfirst.frc2370.RobotV1;

import com.ni.vision.NIVision;
import com.ni.vision.NIVision.Image;
import com.ni.vision.NIVision.ImageType;

import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

class ImageProcessing
{
	static NIVision.Range TOTE_R_RANGE = new NIVision.Range(0, 255);
	static NIVision.Range TOTE_G_RANGE = new NIVision.Range(238, 255);
	static NIVision.Range TOTE_B_RANGE = new NIVision.Range(0, 255);
	
	static NIVision.ParticleFilterCriteria2 criteria[] = new NIVision.ParticleFilterCriteria2[1];
	static NIVision.ParticleFilterOptions2 filterOptions = new NIVision.ParticleFilterOptions2(0,0,1,1);
	
	static NIVision.Image rgbThresholdImage = NIVision.imaqCreateImage(ImageType.IMAGE_U8, 0);
	static NIVision.Image convexHullImage = NIVision.imaqCreateImage(ImageType.IMAGE_U8, 0);
	static NIVision.Image filteredImage = NIVision.imaqCreateImage(ImageType.IMAGE_U8, 0);
	
	public static void init()
	{
		criteria[0] = new NIVision.ParticleFilterCriteria2(NIVision.MeasurementType.MT_AREA, 1000.0, 1000000.0, 0, 0);
	}
	
	// Returns the largest particle in the image, most likely the target
	public static Image Process(Image image)
	{
		// STEP 1: RGB threshold
		//NIVision.imaqColorThreshold(rgbThresholdImage, image, 255, NIVision.ColorMode.RGB, TOTE_R_RANGE, TOTE_G_RANGE, TOTE_B_RANGE);
		NIVision.imaqColorThreshold(rgbThresholdImage, image, 255, NIVision.ColorMode.RGB, TOTE_R_RANGE, TOTE_G_RANGE, TOTE_B_RANGE);
	
		// Step 2: Convex hull
		NIVision.imaqConvexHull(convexHullImage, rgbThresholdImage, 1);
		
		// Step 3: Remove small pieces
		NIVision.imaqParticleFilter4(filteredImage, convexHullImage, criteria, filterOptions, null);
		
		// Step 4: Return the processed image
		return filteredImage;
	}
}
